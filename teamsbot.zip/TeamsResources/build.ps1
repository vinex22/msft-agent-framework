# build.ps1 - Build the Teams app package (Windows PowerShell)
# Usage: .\build.ps1
# Reads values from ..\.env and produces appPackage.zip

$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$EnvFile = Join-Path $RootDir '.env'

if (-not (Test-Path $EnvFile)) {
    Write-Error ".env file not found at $EnvFile"
    exit 1
}

# Load environment variables from .env
$envVars = @{}
Get-Content $EnvFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#')) {
        $parts = $line -split '=', 2
        if ($parts.Count -eq 2) {
            $key = $parts[0].Trim()
            $value = $parts[1].Trim()
            $envVars[$key] = $value
            Set-Item -Path "Env:$key" -Value $value
        }
    }
}

Write-Host "=== Building Teams App Package ===" -ForegroundColor Cyan
Write-Host "Bot Name:     $($envVars['BOT_NAME'])"
Write-Host "Bot Domain:   $($envVars['BOT_DOMAIN'])"
Write-Host "Teams App ID: $($envVars['TEAMS_APP_ID'])"
Write-Host ""

# Create temp build directory
$BuildDir = Join-Path $ScriptDir 'build'
if (Test-Path $BuildDir) { Remove-Item -Recurse -Force $BuildDir }
New-Item -ItemType Directory -Path $BuildDir | Out-Null

# Substitute variables in manifest template
Write-Host "Substituting values into manifest..."
$manifest = Get-Content (Join-Path $ScriptDir 'manifest.template.json') -Raw
$manifest = $manifest -replace '\$\{\{TEAMS_APP_ID\}\}', $envVars['TEAMS_APP_ID']
$manifest = $manifest -replace '\$\{\{AAD_APP_CLIENT_ID\}\}', $envVars['AAD_APP_CLIENT_ID']
$manifest = $manifest -replace '\$\{\{BOT_DOMAIN\}\}', $envVars['BOT_DOMAIN']
$manifest = $manifest -replace '\$\{\{BOT_NAME\}\}', $envVars['BOT_NAME']
$manifest | Set-Content (Join-Path $BuildDir 'manifest.json') -Encoding UTF8
Write-Host "Manifest generated."

# Copy icons
$colorIcon = Join-Path $ScriptDir 'color.png'
$outlineIcon = Join-Path $ScriptDir 'outline.png'
if ((Test-Path $colorIcon) -and (Test-Path $outlineIcon)) {
    Copy-Item $colorIcon (Join-Path $BuildDir 'color.png')
    Copy-Item $outlineIcon (Join-Path $BuildDir 'outline.png')
} else {
    Write-Warning "color.png and/or outline.png not found in $ScriptDir"
    Write-Warning "Add 192x192 color.png and 32x32 outline.png before uploading to Teams."
}

# Deploy Bot Service
Write-Host ""
Write-Host "=== Deploying Bot Service ===" -ForegroundColor Cyan
$bicepPath = Join-Path $RootDir 'deploy\teams-bot.bicep'

az deployment group create `
    --name sre-agent-bot `
    --resource-group $envVars['RESOURCE_GROUP'] `
    --template-file $bicepPath `
    --parameters `
        resourceBaseName=$($envVars['RESOURCE_SUFFIX']) `
        botAadAppClientId=$($envVars['AAD_APP_CLIENT_ID']) `
        botAppDomain=$($envVars['BOT_DOMAIN']) `
        botDisplayName="$($envVars['BOT_NAME'])" `
        microsoftAppType=$($envVars['MICROSOFT_APP_TYPE']) `
        microsoftAppTenantId=$($envVars['MICROSOFT_APP_TENANT_ID']) `
        userAssignedIdentityResourceId=$($envVars['USER_ASSIGNED_IDENTITY_RESOURCE_ID'])

if ($LASTEXITCODE -ne 0) {
    Write-Error "Bot Service deployment failed."
    exit 1
}
Write-Host "Bot Service deployed."

# Create ZIP package
Write-Host ""
Write-Host "=== Creating appPackage.zip ===" -ForegroundColor Cyan
$OutputZip = Join-Path $ScriptDir 'appPackage.zip'
if (Test-Path $OutputZip) { Remove-Item $OutputZip }
Compress-Archive -Path (Join-Path $BuildDir '*') -DestinationPath $OutputZip
Remove-Item -Recurse -Force $BuildDir

Write-Host ""
Write-Host "SUCCESS: $OutputZip created." -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. Open Teams Admin Center: https://admin.teams.microsoft.com/"
Write-Host "  2. Go to Teams apps > Manage apps"
Write-Host "  3. Upload appPackage.zip"
Write-Host "  4. Publish to your organization"
