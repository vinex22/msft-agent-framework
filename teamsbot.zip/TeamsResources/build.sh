#!/bin/bash
# build.sh - Build the Teams app package
# Usage: ./build.sh
# Reads values from ../.env and produces appPackage.zip

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
ENV_FILE="$ROOT_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
  echo "ERROR: .env file not found at $ENV_FILE"
  exit 1
fi

# Load environment variables
set -a
source "$ENV_FILE"
set +a

echo "=== Building Teams App Package ==="
echo "Bot Name:    $BOT_NAME"
echo "Bot Domain:  $BOT_DOMAIN"
echo "Teams App ID: $TEAMS_APP_ID"
echo ""

# Create temp build directory
BUILD_DIR="$SCRIPT_DIR/build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# Substitute variables in manifest template
echo "Substituting values into manifest..."
sed \
  -e "s|\${{TEAMS_APP_ID}}|$TEAMS_APP_ID|g" \
  -e "s|\${{AAD_APP_CLIENT_ID}}|$AAD_APP_CLIENT_ID|g" \
  -e "s|\${{BOT_DOMAIN}}|$BOT_DOMAIN|g" \
  -e "s|\${{BOT_NAME}}|$BOT_NAME|g" \
  "$SCRIPT_DIR/manifest.template.json" > "$BUILD_DIR/manifest.json"

echo "Manifest generated."

# Copy icons
if [ -f "$SCRIPT_DIR/color.png" ] && [ -f "$SCRIPT_DIR/outline.png" ]; then
  cp "$SCRIPT_DIR/color.png" "$BUILD_DIR/color.png"
  cp "$SCRIPT_DIR/outline.png" "$BUILD_DIR/outline.png"
else
  echo "WARNING: color.png and/or outline.png not found in $SCRIPT_DIR"
  echo "  The app package will not include icons. Add 192x192 color.png and 32x32 outline.png."
fi

# Deploy Bot Service
echo ""
echo "=== Deploying Bot Service ==="
az deployment group create \
  --name sre-agent-bot \
  --resource-group "$RESOURCE_GROUP" \
  --template-file "$ROOT_DIR/deploy/teams-bot.bicep" \
  --parameters \
    resourceBaseName="$RESOURCE_SUFFIX" \
    botAadAppClientId="$AAD_APP_CLIENT_ID" \
    botAppDomain="$BOT_DOMAIN" \
    botDisplayName="$BOT_NAME" \
    microsoftAppType="$MICROSOFT_APP_TYPE" \
    microsoftAppTenantId="$MICROSOFT_APP_TENANT_ID" \
    userAssignedIdentityResourceId="$USER_ASSIGNED_IDENTITY_RESOURCE_ID"

echo "Bot Service deployed."

# Create ZIP package
echo ""
echo "=== Creating appPackage.zip ==="
OUTPUT_ZIP="$SCRIPT_DIR/appPackage.zip"
rm -f "$OUTPUT_ZIP"
(cd "$BUILD_DIR" && zip -r "$OUTPUT_ZIP" .)
rm -rf "$BUILD_DIR"

echo ""
echo "SUCCESS: $OUTPUT_ZIP created."
echo ""
echo "Next steps:"
echo "  1. Open Teams Admin Center: https://admin.teams.microsoft.com/"
echo "  2. Go to Teams apps > Manage apps"
echo "  3. Upload appPackage.zip"
echo "  4. Publish to your organization"
