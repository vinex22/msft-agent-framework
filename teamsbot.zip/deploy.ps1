# deploy.ps1 - Create resource group and run the full deployment
# Usage: .\deploy.ps1
# This script:
#   1. Creates the Azure resource group (if needed)
#   2. Invokes the TeamsResources\build.ps1 which deploys Bot Service + builds the app package

$ErrorActionPreference = 'Stop'

$RootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$EnvFile = Join-Path $RootDir '.env'

if (-not (Test-Path $EnvFile)) {
    Write-Error ".env file not found at $EnvFile"
    exit 1
}

# Load .env
$envVars = @{}
Get-Content $EnvFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#')) {
        $parts = $line -split '=', 2
        if ($parts.Count -eq 2) {
            $envVars[$parts[0].Trim()] = $parts[1].Trim()
        }
    }
}

$ResourceGroup = $envVars['RESOURCE_GROUP']
$Location = 'eastus2'

# Verify Azure CLI is logged in
Write-Host "Checking Azure CLI login..." -ForegroundColor Cyan
$account = az account show 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "Not logged in. Running az login..." -ForegroundColor Yellow
    az login
}

# Create resource group
Write-Host ""
Write-Host "=== Creating Resource Group: $ResourceGroup ===" -ForegroundColor Cyan
az group create --name $ResourceGroup --location $Location --output table
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to create resource group."
    exit 1
}
Write-Host "Resource group ready."

# Run the build script (deploys Bot Service + creates app package)
Write-Host ""
Write-Host "=== Running Teams Bot build & deploy ===" -ForegroundColor Cyan
$buildScript = Join-Path $RootDir 'TeamsResources\build.ps1'
& $buildScript
