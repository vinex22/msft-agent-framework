@description('Base name for the bot resources')
param resourceBaseName string

@description('The AAD app client ID for the bot (managed identity client ID)')
param botAadAppClientId string

@description('The domain of the bot app (agent FQDN without https://)')
param botAppDomain string

@description('Display name for the bot in Teams')
param botDisplayName string = 'SRE Agent Bot'

@description('The Microsoft app type')
@allowed([
  'UserAssignedMsi'
  'SingleTenant'
  'MultiTenant'
])
param microsoftAppType string = 'UserAssignedMsi'

@description('The Microsoft Entra tenant ID')
param microsoftAppTenantId string

@description('The full resource ID of the user-assigned managed identity')
param userAssignedIdentityResourceId string = ''

resource bot 'Microsoft.BotService/botServices@2022-09-15' = {
  name: resourceBaseName
  location: 'global'
  kind: 'azurebot'
  sku: {
    name: 'S1'
  }
  properties: {
    displayName: botDisplayName
    endpoint: 'https://${botAppDomain}/api/messages'
    msaAppId: botAadAppClientId
    msaAppType: microsoftAppType
    msaAppTenantId: microsoftAppTenantId
    msaAppMSIResourceId: !empty(userAssignedIdentityResourceId) ? userAssignedIdentityResourceId : null
  }
}

resource teamsChannel 'Microsoft.BotService/botServices/channels@2022-09-15' = {
  parent: bot
  name: 'MsTeamsChannel'
  location: 'global'
  properties: {
    channelName: 'MsTeamsChannel'
  }
}

output botId string = bot.id
output botName string = bot.name
output messagingEndpoint string = 'https://${botAppDomain}/api/messages'
